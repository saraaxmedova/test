import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // type array_name[];

        // array_name = new type[size];

//        int arr[] = new int[10];
//
//        for (int i = 0; i < arr.length; i++) {
//            arr[i] = i + 1;
//        }
//        int x;
//        for (int i = 0; i <= arr.length / 2; i++) {
//            x = arr[i];
//            arr[i] = arr[arr.length - i - 1];
//            arr[arr.length - i - 1] = x;
//        }
//        // 10 9 8 7 6 5 4 3 2 1
//        for (int y : arr) {
//            System.out.print(y + " ");
//        }

        // type arr_name[][] = new type[size1][size2];
        int k = 1;
        int arr[][] = new int[4][4];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                arr[i][j] = scanner.nextInt();
                if(i==j)
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }

        int g = arr.length - 1;
        for(int i = 0; i < 4; i++)
        {
            System.out.print(arr[i][g--] + " ");
        }

//        1 2 3 4
//        5 6 7 8
//        9 1 2 3
//        4 5 6 7

//        for (int x[] : arr) {
//            for (int y : x) {
//                System.out.print(y + " ");
//            }
//            System.out.println();
//        }

//        String str = "   this is   gtest   ";
//        System.out.println(str.length());
//
//        char ch[] = {'t', 'e', 's', 't', '!'};
//        String str1 = new String(ch) + " ----";
//        String str2 = new String("this is test");
//        String str3 = new String(str);
//        System.out.println(str1);
//        System.out.println(str.charAt(3));
//        System.out.printf("%.4s", str);
//        System.out.println(str.endsWith("test"));
//        System.out.println(str.lastIndexOf("is"));
//        str = str.replace('g', ' ');
//        System.out.println(str.trim());
    }
}