import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int arr[] = new int[n], count = 0;
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }
        Arrays.sort(arr);

        for (int i = 1; i < n; i++)
            if (arr[i] != arr[i - 1])
                count++;

// 5 19 22 19 22
        //5 19 19 22 22
        System.out.println(count + 1);
    }
}
