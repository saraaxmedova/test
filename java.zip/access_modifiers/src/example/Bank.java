package example;

public abstract class Bank {

    final int pass = 164981;
    abstract void showname();
}
class  Gandjlikbank extends  Bank{

    int pass = 2324;
    @Override
    void showname() {
        System.out.println("Gandjlikbank");
    }
}
