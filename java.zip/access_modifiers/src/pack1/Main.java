package pack1;

import astract.Figur;
import pack.Test;
import pack.pack2.*;
import pack.pack2.Test1;

import java.util.Date;
//import java.sql.Date;
import java.io.*;

public class Main extends Test {
    public static void main(String[] args) {
//
//        Date d = new Date();
//        Test1 t1 = new Test1();
//        Main m = new Main();
//        Test3 t3 = new Test3();
//        m.x = 12;
//        System.out.println(m.x);
//        m.z = 15;
        Figur f ;


    }
}
