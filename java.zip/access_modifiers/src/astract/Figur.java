package astract;

public abstract class Figur {

    int x;
    int y;
Figur()
{

}
    public void show() {
        System.out.println("x = " + x + " , y = " + y);
    }

    public abstract void area();
}

class Duzbucaqli extends Figur {

    @Override
    public void area() {
        System.out.println("sahe = " + x * y);
    }
}

class Triangle extends Figur {
    @Override
    public void area() {
        System.out.println("sahe = " + x * y / 2);
    }
}