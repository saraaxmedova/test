package astract;

import com.sun.management.GarbageCollectionNotificationInfo;
import example.Bank;

public class Test {

    public static void main(String[] args) {
//        Figur f ;
//        Duzbucaqli d=new Duzbucaqli();
//        d.x=12;
//        d.y=13;
//        f = d;
//        f.area();
        Bank bank;

    }
}
/*
*
* datadb;
*
* */