package astract;

import java.sql.Date;

public class Person {

    private String name;

    private String surname;

    private Date birthDate;

}
