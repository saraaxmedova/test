package pack;

public class Main1 extends Test{

    public static void main(String[] args) {
        Main1 m = new Main1();

        m.x = 90;
        m.y = 34;
        m.z = 23;
    }
}