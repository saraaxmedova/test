package pack;

public class Test {

    public int x;
    int y;
    protected int z;
    private int t;

}
