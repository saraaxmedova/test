import java.util.Scanner;

public class Main {
    static boolean leap_year(int year) {
        boolean isLeapYear;

        isLeapYear = (year % 4 == 0);
        isLeapYear = isLeapYear && (year % 100 != 0);
        isLeapYear = isLeapYear || (year % 400 == 0);
        return isLeapYear;
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int day = scanner.nextInt();
        int month = scanner.nextInt();
        int year = scanner.nextInt();
        if (day == 31 && (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)) {
            if (month == 12) {
                day = 2;
                month = 1;
                year = year + 1;
            } else {
                day = 2;
                month = month + 1;
            }
        } else if (day == 30 && (month == 4 || month == 6 || month == 9 || month == 11)) {
            day = 2;
            month = month + 1;
        } else if (day == 30 && (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)) {

            if (month == 12) {
                day = 1;
                month = 1;
                year = year + 1;
            } else {
                day = 1;
                month = month + 1;
            }
        } else if (day == 28 && month == 2 && !leap_year(year)) {
            day = 2;
            month = month + 1;
        } else if (day == 28 && month == 2 && leap_year(year)) {
            day = 1;
            month = month + 1;
        } else day += 2;
        System.out.println(day + " " + month + " " + year);
    }
}

