import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int k = 0, count = 1;
        Scanner scanner=new Scanner(System.in);
        int n = scanner.nextInt();
        for(int i = 1, j = 1; count <= n;)
        {
            System.out.print(j+ " ");
            k++;
            count++;

            if(k == i)
            {
                j++;
                k = 0;
//			i++;
            }
        }
    }
}
