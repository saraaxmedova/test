import java.sql.SQLException;
import java.util.Scanner;
//import java.util.Scanner;

public class Sodali_suyun_catdirlmasi {

    public static void main(String[] args) throws SQLException {

        Scanner scan = new Scanner(System.in);
        int bos = scan.nextInt(), topla = scan.nextInt(), c = scan.nextInt();
        int cemi = 0;
        bos += topla;

        while (bos >= c) {
            cemi += bos / c; //  5
            bos = (bos % c) + (bos / c); // 5
        }
        System.out.println(cemi);
    }
}