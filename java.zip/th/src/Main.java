import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int iDay = scanner.nextInt();
        int iMonth = scanner.nextInt();
        int iYear = scanner.nextInt();
        if (iDay >= 1 && iDay <= 31 && iMonth >= 1 && iMonth <= 12) {
            nextDay(iDay, iMonth, iYear);
        } else
            System.out.println("invalid syntax!!");

    }

    public static int daysMonth(int iMonth) {
        if (iMonth >= 1 && iMonth <= 12) {
            if (iMonth == 2)
                return 28;

            if (iMonth == 4 || iMonth == 6 || iMonth == 9 || iMonth == 11)
                return 30;

            return 31;
        }
        return 0;
    }

    public static void nextDay(int iD, int iMonth, int iY) {
        int daysM = daysMonth(iMonth);

        if (iD != daysM) {
            iD = iD + 1;
            iMonth = iMonth;
            iY = iY;
            System.out.println("here");
            System.out.println(iD + " " + iMonth + " " + iY);

        } else if (iD == daysM) {
            iD = 1;
            iMonth = iMonth + 1;
            iY = iY;
        } else if ((iMonth == 12) && (iD == 31)) ;
        {
            iD = 1;
            iMonth = 1;
            iY = iY + 1;
        }

        System.out.println(iD + " " + iMonth + " " + iY);
    }
}