import java.io.FileNotFoundException;
import java.sql.SQLException;

public class Main {

    int x = 45;
    static  void method() throws SQLException
    {
            throw new SQLException();
    }
    public static void main(String[] args)  throws  Exception{

        try {
            int a = 3, b = 10;
            System.out.println(a / b);
        } catch (ArithmeticException a) {
            System.out.println("sifira bolmek olmaz");
        } catch (Exception e) {
            System.out.println("Exception klasi");
        }
        finally {
            System.out.println("finally block");
        }
        try {
            throw new ArithmeticException();
        } catch (Exception e)
        {}
        try {
            int arr[] = {1, 2, 3};
            System.out.println(arr[3]);
        } catch (ArrayIndexOutOfBoundsException a) {
        }
        try {
            Main m = null;
            System.out.println(m.x);
        } catch (NullPointerException n) {
            System.out.println(n.getMessage());
        }
        //throw new FileNotFoundException();
    }
} // try catch throw throws finally