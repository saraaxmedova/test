public class Main {

  public static void main(String[] args) {
    Main2 Obj1 = new Main2();
    Main2 Obj2 = new Main2();
    System.out.println(Obj1.x);
    System.out.println(Obj2.x);
  }
}
class Main2{
  int x = 6;
}
