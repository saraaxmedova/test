import java.util.Scanner;

public class Main {
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        char a[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
        String arr = in.nextLine();
        int count = 0;
        char olm[] = new char[20];
        int k = 0;
        boolean b = false;

        for (int i = 0; i < 10; i++) { // a
            for (int j = 0; j < arr.length(); j++) {

                if (arr.charAt(j) == a[i]) {
                    b = true;
                    break;
                }
            }
            if (!b) {
                count++;
                olm[k++] = a[i];
            }
            b = false;
        }
        System.out.println(count);
        for (int i = 0; i < olm.length; i++) {
            System.out.print(olm[i] + " ");
        }
    }
}


