package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        FlowPane flowPane=new FlowPane();
        flowPane.setAlignment(Pos.CENTER);
        primaryStage.setTitle("Hello");
        primaryStage.setScene(new Scene(flowPane, 300, 275));
        Label label=new Label("hi everyone!!");
        flowPane.getChildren().add(label);
        Button button=new Button("lsls");
        Button button1=new Button("jdkd");
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                label.setText("jkdfjkd");
            }
        });
        button1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                label.setText("ls;d;kw");
            }
        });
//        flowPane.getChildren().addAll(button,button1);
        Image image=new Image("imag.jpg");
        ImageView imageView=new ImageView(image);
//        flowPane.getChildren().add(imageView);
        Separator separator = new Separator();
        separator.setPrefWidth(100);
        Label label1 = new Label("Exam", imageView);
        label1.setContentDisplay(ContentDisplay.LEFT);
        flowPane.getChildren().addAll(button,button1,separator,label1);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
