public class Main {

    public static void main(String[] args) {

        System.out.println();
        Main gcd = new Main();
        LCM lcm = new LCM();
        System.out.printf("GCD of a and b is" + gcd.Gcd(8, 6));
        System.out.printf("LCM of a nad b " + lcm.Lcm(8, 6));
    }

    public static int Gcd(int a, int b) {
        int gcd = 1;
        for (int i = 1; i <= a && i <= b; i++) {
            if (a % i == 0 && b % i == 0)
                gcd = i;
        }
        return gcd;
    }
}