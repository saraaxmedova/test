import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int n, m, t = 1;
        Scanner in = new Scanner(System.in);
        m = in.nextInt();
        n = in.nextInt();
        int arr[][] = new int[m][n];
        int transpose[][] = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                arr[i][j] = t++;
            }
        }

        int temp;

        for (int i = 0, k = m - 1; i < m / 2; i++, k--) {
            for (int j = 0, l = n - 1; j < n; j++, l--) {
                temp = arr[i][j];
                arr[i][j] = arr[k][l];
                arr[k][l] = temp;
            }
        }
// i = 2 k = 0 j = 2 l = 0

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.print("\n");
        }
    }
}