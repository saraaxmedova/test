public class Main {
    public static void main(String[] args) {
        Main f10 = new Main();
        System.out.println(f10.Fun10(2 , 4));
    }
    public static int Fun10(int m, int n) {
        if (m == 0)
            return 1;
        else if (0 < m && n > m)
            return Fun10(m - 1, n - 1) + Fun10(m, n - 1); // f(1, 3) + f(2, 3) = 6
        else if(m == n) //f(1, 3)=> 3
            return 1;// f(2, 3) => 3
        return 0;//f(1, 2) => 1 + 1
    }
}