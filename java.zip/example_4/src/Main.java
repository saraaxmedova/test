public class Main {

    public static void main(String[] args) {
//        int m=0;
//      while(m<6)
//      {
//          System.out.print(m+" ");
//          m++;
//for(int k=0;k<7;k++)
//    System.out.print(k+" ");
//        System.out.println( );
//for (int a=0;a<=20;a+=2)
//    System.out.print(a+" ");
//        System.out.println();
//        for (int l=1;l<20;l+=2)
//            System.out.print(l+" ");
//        String[] s = {"men", "sen", "o", "biz", "siz", "onlar"};
//        for (String k : s)
//            System.out.print(k + "  ");
//        for (int i = 0; i < 6; i++) {
//            if (i == 4) {
//                break;
//            }
//            System.out.print(i + "  ");
//        }
//        System.out.println();
//            for (int j=0;j<6;j++)
//            {
//                if (j==2){
//                    continue;
//                }
//                System.out.print(j+"  ");
//            }
            int c=0;
            while (c<10){
                if (c==6){
                    break;
                }
                System.out.print(c+"  ");
                c++;
            }
        System.out.println();
            int b=0;
            while(b<10){
                if (b==6){
                    b++;
                    continue;
                }
                System.out.print(b+"  ");
                b++;

            }
        }
    }

