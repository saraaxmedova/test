public class generic <T, V>{

    T a;
    V b;

    generic(T a,V b)
    {
        this.a = a;
        this.b = b;
        System.out.println("constructor");
    }

    public void showType()
    {
        System.out.println(a.getClass().getName());
        System.out.println(b.getClass().getName());
    }

    public T getA()
    {
        return a;
    }
}
