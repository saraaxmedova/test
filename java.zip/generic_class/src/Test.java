public class Test {


    static <T extends Number> void avarage(T[] t)
    {
        double result = 0.0;

        for(T x : t)
        {
            result += x.doubleValue();
        }

        System.out.println(result/t.length);
    }

    public static void main(String[] args) {

        Integer[] values = {1, 3, 3, 56};
        avarage(values);
//        generic<Integer, Integer> obj;
//
//        obj = new generic<Integer, Integer>(14, 159);
//
//        System.out.println(obj.getA());
//        obj.showType();
//        generic<String, Character> obj1;
//        obj1 =new generic<String, Character>("jfkdsd", 'c');
//        System.out.println((obj1.getA()));
//        obj1.showType();
    }
}
