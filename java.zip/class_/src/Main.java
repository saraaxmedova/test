public class Main {

    static int x = 90;

    public static void main(String[] args) {

        final double PI = 3.14;

        Rectangle r;
        r = new Rectangle();
        Rectangle r1;
        r1 = new Rectangle();
        r1.a = 15;
        r1.b = 35;
//        System.out.println(r1.recS());
//        System.out.println(r.recP());
        r.recProperties();

        Rectangle obj1 = new Rectangle();
        obj1.a = 21;
        obj1.b = 9;

        Rectangle obj2 = obj1;

        System.out.println(obj2.a);
        System.out.println("--------------------------");
        Main m = new Main();
        System.out.println(m.max(21, 30));
        System.out.println(m.max(15, m.x));
        test t = new test();
        t.meth2(16, "test");
        System.out.println(t.meth3());
        String s = t.meth3();
        System.out.println(t.meth4(6,"java"));

    }

    int max(int x, int y) {
        return x > y ? x : y;
    }
}
class test {
    int x;

    void meth1() {

    }

    void meth2(int x, String a) {
        System.out.println("Ad = " + a + " yas = " + x);
    }

    String meth3() {
        return "bos method";
    }

    String meth4(int x, String a) {
        System.out.println("Ad = " + a + " yas = " + x);
        return "sas";
    }

}