public class Rectangle {

    int a = 10, b = 20;

    int recS() {
        return a * b;
    }

    int recP() {
        return (a + b) * 2;
    }
    void recProperties()
    {
        Rectangle r = new Rectangle();
        r.a = 6;
        System.out.println("P = " + recP());
        System.out.println("S = " + recS());
        System.out.println(Main.x);

    }
}