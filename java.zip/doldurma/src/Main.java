import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int n, t = 1;
        Scanner in = new Scanner(System.in);
        n = in.nextInt();
        int arr[][] = new int[n][n];
        for (int i = 0; i < n; i++) {
            if (i % 2 == 0)
                for (int j = 0; j < n; j++) {
                    arr[i][j] = t++;
                }
            else if (i % 2 != 0)
                for (int j = n - 1; j >= 0; j--)
                    arr[i][j] = t++;
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.print("\n");
        }
    }
}