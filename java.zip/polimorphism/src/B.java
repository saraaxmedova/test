public
class B extends A {

    int k;

    void show_k() {
        System.out.println("k = " + k);
    }
    void show_all()
    {
        System.out.println(i);
        System.out.println(getJ());
        show_k();
    }
}
class C extends B{

}