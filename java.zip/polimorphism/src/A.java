public class A {
    int i;
    private int j;

    public int getJ() {
        return j;
    }

    public void setJ(int j) {
        this.j = j;
    }

    private void show_i_j() {
        System.out.println("i = " + i + " , j = " + j);
    }
}
