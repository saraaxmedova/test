public class Main {

    public static void main(String[] args) {

        A a = new A();
        a.i = 32;
        a.setJ(12);

        System.out.println(a.getJ());

        B b = new B();
        b.i = 45;
        b.setJ(6);
        b.k = 15;
//        b.show_i_j();
        b.show_k();

        A aa = new B();

        a = b;
        System.out.println("--------");
//        a.show_i_j();
        ((B) a).show_k();
        System.out.println("-------------------");
        C c=new C();
        c.i=13;
//        c.j=33;
        c.k=24;
//        c.show_i_j();
        c.show_k();
        a = c;
    }
}
