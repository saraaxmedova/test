public class Lesson {

    public void simple(int n)
    {
        int count = 0;
        if (n == 1) {
            System.out.println("ne sade ne de murekkeb");
        } else {
            for (int i = 1; i <= n; i++) {
                if (n % i == 0) {
                    count++;
                }
            }
            if (count == 2) {
                System.out.println("sadedir");
            }
            else {
                System.out.println("murekkeb");
            }
        }
    }
}
