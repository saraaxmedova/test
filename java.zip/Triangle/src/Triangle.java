import java.util.Scanner;

public class Triangle {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int n = input.nextInt();Lesson l;
        l = new Lesson();

        l.simple(n);
    }
}