package com.example;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String str = scanner.next();
        int count = 1;
        char[] arr = str.toCharArray();
        for (int i = 0; i < str.length(); i++) {
            if (arr[i] == arr[i + 1])
                count++;
            else if (arr[i] != arr[i + 1] && count == 2) {
                for (int j = i - 1; arr[j] != '\0'; i = -1, j++)
                    arr[j] = arr[j + count];
                count = 1;
            } else if (arr[i] == arr[i + 1] && count > 2) {
                arr[i - count + 1] = arr[i];
                for (int j = i - count + 2; arr[j] != '\0'; i = 0, j++)
                    arr[j] = arr[j + count - 1];
                count = 1;

            } else if (arr[i] != arr[i + 1]) {
                count = 1;
            }
        }
//wwstdaadierfflitzzz
    }
}
