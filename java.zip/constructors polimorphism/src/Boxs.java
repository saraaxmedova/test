public class Boxs {
    int width;
    private int height;
    int length;

    public Boxs() {
        this(10);
        System.out.println("no parameter!!");
    }

    public Boxs(int a) {
        this(a, 20);
        this.width = a;
        System.out.println("one parameter");
    }

    public Boxs(int a, int b) {
        this(a, b, 30);
        this.width = a;
        this.height = b;
        System.out.println("two parameters");
    }

    public Boxs(int a, int b, int c) {
        this.width = a;
        this.height = b;
        this.length = c;
        System.out.println("three parameters");
    }

    public int Volume() {
        return width * height * length;
    }
}

class Boxs1 extends Boxs {
    int tutum;

    public Boxs1() {
        super(23, 24, 25);
        this.tutum = 12;
        System.out.println("no parameter!!");
    }

    public Boxs1(int i) {
        super(i, 24, 25);
        System.out.println("one parameter");
    }

    public Boxs1(int i, int j) {
        super(i, j, 30);
        System.out.println("two parameters");
    }

    public void show() {
        System.out.println(tutum);
        System.out.println(super.Volume());
    }
}