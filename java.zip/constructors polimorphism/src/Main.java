public class Main {

    public static void main(String[] args) {

//        Test t1 = new Test(12, 5);
//        t1.show();
//        Test t2 = new Test();
//        t2.show();

//        A a = new A();
//        A a1 = new A(16, 19);
//        a1.show();
//
//        B b = new B(48);
//
//        b.show_k();
//
//        C c = new C();
//        c.show_k();

//        Boxs b = new Boxs();
//        System.out.println(b.Volume());
//
//        Boxs b1=new Boxs(10);
//        System.out.println(b1.Volume());
//
//        Boxs b2=new Boxs(10,20);
//        System.out.println(b2.Volume());

//        Boxs1 b1 = new Boxs1();
//        b1.show();
//        Boxs1 b2 = new Boxs1(20  );
//        b2.show();
//        Boxs1 b3 = new Boxs1(20,30);
//        b3.show();

        Base b2=new Base(12, 110);
        System.out.println(b2.Per());
    }
}