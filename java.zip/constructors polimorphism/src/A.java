public class A {
    int i, j;

    A(int i, int j) {
        this.i = i;
        this.j = j;
        System.out.println("two parameters");
    }

    A() {
        System.out.println("constructor in A");
    }

    void show() {
        System.out.println("i = " + i + " , j = " + j);
    }
}

class B extends A {

    int k;

    B() {
        super();
        System.out.println("constructor in B");
    }

    B(int k) {
        super(12, 7);
        this.k = k;
        System.out.println("one parameter");
    }

    public B(int i, int i1, int i2) {
        super(i, i1);
        this.k=i2;
    }

    void show_k() {
        super.show();
        System.out.println("k = " + k);
    }
}

class C extends B {

    C() {
        super(23, 4, 9);
        System.out.println("constructor in C");
    }
}