public class Base {
    int eni, uzun;

    public Base() {
        System.out.println("no parameter");
    }

    public Base(int m) {
        this.eni = m;
        System.out.println("one parameter");
    }

    public Base(int m, int n) {
        this.eni = m;
        this.uzun = n;
        System.out.println("two parameter");
    }

    public int Per() {
        return 2 * (eni + uzun);
    }

    public int Sahe() {
        return eni * uzun;
    }

    public void show() {
        System.out.println("perimetri = " + Per());
        System.out.println("sahe = " + Sahe());
    }
}

class Derived extends Base {
    int hundur;

    public Derived() {
        super(1, 1);
        System.out.println("no parameter");
    }

    public Derived(int a) {
        super(a, a);
        this.hundur = a;
    }

    public Derived(int a, int b) {
        super(b, b);
        this.hundur = a;
    }
    public void showBase() {
        super.show();
        System.out.println("hundurluk = " + hundur);
    }
}