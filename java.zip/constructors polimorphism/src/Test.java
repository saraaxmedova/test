public class Test {
    int i;
    int j;
    int k;

    Test() {
        this(1);
        System.out.println("without parameter");
    }

    Test(int i) {
        this(i, i);
        this.i = i;
        System.out.println("one parameter");
    }

    Test(int i, int j) {
        this(i, i, i);
        this.i = i;
        this.j = j;
        System.out.println("two parameter");
    }

    Test(int i, int j, int k) {
        this.i = i;
        this.j = j;
        this.k = k;
        System.out.println("three parameter");
    }

    public void show() {
        System.out.println("i = " + i + " , j = " + j + " , k = " + k);
    }
}
