public class Stringg {

    public String str;

    Stringg(String str) {
        this.str = str;
    }

    Stringg() {
    }

    public int length(Stringg s) {

        int length = 0;

        for (char c : s.str.toCharArray())
            length++;

        return length;
    }

    public int length(String s) {

        int length = 0;

        for (char c : s.toCharArray())
            length++;

        return length;
    }

    public char[] toCharArray(Stringg str) {
        char arr[] = new char[str.str.length()];
        for (int i = 0; i < str.str.length(); i++)
            arr[i] = str.str.charAt(i);
// str[i]
        return arr;
    }
}

class String1 extends Stringg {
    @Override
    public int length(String s) {
        return s.length();
    }
}