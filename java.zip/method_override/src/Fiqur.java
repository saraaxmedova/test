public class Fiqur {

    int a;
    int b;

    public Fiqur(int a, int b)
    {
        this.a = a;
        this.b = b;
    }
    public Fiqur(){}
    public void area()
    {
        System.out.println("namelum figur \n Sahesi = " + 0);
    }
}
class Duzbucaqli extends Fiqur{

    public Duzbucaqli(int a, int b)
    {
        super(a, b);
    }
    @Override
    public void area()
    {
        System.out.println("inside Duzbucaqli.\n Sahesi = " + a * b);
    }
}

class Ucbucaq extends Fiqur{

    Ucbucaq ()
    {
        super();
    }
    Ucbucaq (int oturacaq, int hundurluk)
    {
        super(oturacaq, hundurluk);
    }
    public void area()
    {
        System.out.println("inside Ucbucaq \n Sahesi = " + (a * b) / 2);
    }

}