public class Main {

    public static void main(String[] args) {
//        Fiqur f =new Fiqur(15, 20);
//        f.area();
//        Duzbucaqli d = new Duzbucaqli(15, 16);
//        d.area();
//        Ucbucaq u = new Ucbucaq(12, 11);
//        u.area();
//
//        Fiqur fref = new Fiqur(12, 10);
//        System.out.println("before assign");
//        fref.area();
//        fref = d;
//        System.out.println("after ");
//        fref.area();
//
//        fref=u;
//        fref.area();

        String s = new String("saf0");
        Stringg s1 = new Stringg("sakamsd");
        System.out.println(s1.length(s));
        System.out.println(s1.length(s1));
        System.out.println(s1.toCharArray(s1));

        String str = "Salam Sara.";
        System.out.println(str.indexOf("Sara"));

    }
}
//final class String1 {
//    void show(){}
//}
//class String2 extends String{} // cannot extends