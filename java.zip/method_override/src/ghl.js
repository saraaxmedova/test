<html>
<head>
<title> Java Script 10 </title>
</head>
<body>
<script type="text/javascript">
var arr=new Arra("xxx xxx","xxx xxx","xxx xxx","xxx xxx","xxx xxx","xxx xxx");
document.write("<table border='1' cellspacing='0' cellpadding='0'>");
for(var i=0;i<=5;i++)
{
    document.write("<tr><td width='90' height='30'>",i,"</td><td width='200'>", arr[i],"</td></tr>");
}
document.write("</table");
</script>
</body>
</html>