import java.util.Scanner;

public class Lesson {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String name;
        int age;
        Students arr[] = new Students[5];

        for (int i = 0; i < 5; i++) {
            name = in.next();
            age = in.nextInt();
            arr[i] = new Students(name, age);
        }
        for (int i = 0; i < 5; i++) {
            System.out.println(i + 1 + " . Name = " + arr[i].name + " - " + arr[i].age);
        }
    }
}
