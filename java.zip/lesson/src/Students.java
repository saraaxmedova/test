public class Students {
    int age;
    String name;

    public Students() {
        name = "no name";
        age = 20;
    }

    public Students(String name, int givenage) {
        age = givenage;
        name = name;
    }
}