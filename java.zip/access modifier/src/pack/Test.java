package pack;

public class Test {

    public int x;

}