import pack.Test;

public class Main {

    public static void main(String[] args) {
        TestDef t = new TestDef();
        t.setX(32);
        System.out.println(t.getX());
        Test test = new Test();
        test.x = 43;
    }
}