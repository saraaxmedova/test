public class TestDef {
    /*
     *
     * public
     * private
     * protected
     * default
     *
     * */

    private int x;
    private String s;

    public void show() {
        System.out.println(x + " from src/TestDef");
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public String getS() {
        return s;
    }

    public void setS(String s) {
        this.s = s;
    }

    // private -> protected -> default -> public
}