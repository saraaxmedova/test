public class Main {
static void s(){
    System.out.println("hiiiiii");
}
static void s(String sr){
    System.out.println(sr+" "+ "hkjgj");
}
static int i(int a){
    return a+3;
}
    static int i(int a,int b){
        return a+b;
    }
    static void check(int m)
    {
        if (m>16){
            System.out.println("goog girl");
        }
        else
            System.out.println("not so goog");
    }
    public static void main(String[] args) {
      s();
      s("sara");
      s("mama");
        System.out.println(i(7));
        System.out.println(i(6,2));
        check(23);
        check(12);
    }
}
