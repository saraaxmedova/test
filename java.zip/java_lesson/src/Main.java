import java.util.Scanner;
public class Main {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        float n = scanner.nextFloat();
        float p= 3*n;
       //4 double s=
        String srt= String.format("%.2f", p);
                System.out.println( float p);
      //  System.out.printf("sqrt(%.4f) is %.3f%n", s, Math.sqrt(s));

    }
}