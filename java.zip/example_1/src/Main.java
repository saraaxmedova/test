public class Main {

    public static void main(String[] args)
    {
        System.out.println("Hello World!");
        String s="first";
        int i=12;
        float f=12.4f;
        System.out.println(s+" "+i+" "+f);
        int x=2,y=3;
        System.out.println(x+y);
        double d=12e5d;
        float f1=3e2f;
        System.out.println(d+" " +f1);
    }
}
