import java.util.Scanner;
public class Main
{
    static Scanner in = new Scanner(System.in);
    public static void main(String args[])
    {
        int n = in.nextInt();
        int one = 0, count = 0;

        int[][] a = new int[n][n];

        for(int i = 0; i < n; i++)
        {
            one = 0;
            for(int j = 0; j < n; j++)
            {
                a[i][j] = in.nextInt();
                if(a[i][j] == 1) one++;
            }
            if(one == 1) count++;
        }
        System.out.println(count);
    }
}