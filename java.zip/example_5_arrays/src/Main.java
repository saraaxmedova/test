public class Main {

    public static void main(String[] args)
    {
//        String[] arr={"happy","unnhappy","certain","uncertain"};
//        System.out.println(arr[1]);
//        arr[0]="funny";
//        System.out.println(arr[0]);
//        System.out.println(arr.length);
//        for (int i=0;i<arr.length;i++)
//            System.out.print(arr[i]+"  ");
//        for (String a : arr)
//            System.out.println(a);
        int[][] a={{1,2,3},{3,4,5},{4,6,7,8}};
        for (int i=0;i<a.length;i++)
            for (int j=0;j<a[i].length;j++)
                System.out.print(a[i][j]+"  ");
    }
}
