import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // 123322
        int n = scanner.nextInt();
        int arr[] = new int[20], length = 0;

        while (n > 0) {
            arr[length] = n % 10;
            length++;
            n /= 10;
        }
        int simm_der = 0;
        for (int i = 0, j = length - 1; i < length / 2; i++, j--)
            if (arr[i] == arr[j])
                simm_der++;

        System.out.println(simm_der);
    }
}
