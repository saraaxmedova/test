public class Main {

    public static void main(String args[]) {
        Parent b = new Parent();
        Boy b1 = new Boy();
        Girl b2 = new Girl();
        Parent pref = new Parent();
        pref = b;
        b.eat();
        pref = b1;
        b1.eat();
        pref = b2;
        b2.eat();
    }
}
// 123 322
class Parent {
    public void eat() {
        System.out.println("Parent is eating");
    }
}

class Boy extends Parent {
    @Override
    public void eat() {
        System.out.println("Boy is eating");
    }
}

class Girl extends Boy {
    @Override
    public void eat() {
        System.out.println("Girl is eating");
    }
}