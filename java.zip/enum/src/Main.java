enum Season {

    SUMMER, SPRING, AUTHMN, WINTER

}

public class Main {
    public static void main(String[] args) {

        Season season[] = Season.values();

        for(Season s: season){
            System.out.println(s + " index = " + s.ordinal() );
        }

        System.out.println(Season.valueOf("SPRING"));


    }
}
