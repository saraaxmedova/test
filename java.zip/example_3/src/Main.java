public class Main {

    public static void main(String[] args) {

//        int x=5,y=5;
//        System.out.println(x>y);
//        System.out.println(x==y);
//        if (x<y)
//            System.out.println("false statement");
//        else if(x>y)
//            System.out.println("true statement");
//        else
//            System.out.println("equal statement");
//        int m=34,n=23;
//        String c=(m>n)? "true" : "false";
//        System.out.println(c);
        switch ("me"){
            case "u":
                System.out.println("sen");
                break;
            case "he":
                System.out.println("o");
                break;
            case "we":
                System.out.println("biz");
                break;
            case "me":
                System.out.println("men");
                break;
                default:
                    System.out.println("onlar");
        }

    }
}
