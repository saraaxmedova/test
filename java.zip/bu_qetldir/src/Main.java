import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int a[] = new int[n];
        int sum1 = 0, sum2 = 0;
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }
        for (int i = 0; i < n; i++) {
            sum1 = 0;
            for (int j = 0; j < i; j++)
                if (a[i] > a[j])
                    sum1 += a[j];
            sum2 += sum1;
        }
        System.out.println(sum2);
    }
}
