public class Main {

    public void f(int a, int b) {
        a = 90;
        b = 40;
    }

    public Test f(Test ob) {
        ob.a = 90;
        ob.b = 40;

        return ob;
    }

    public boolean Equal(Test t, Test t1, Test t2) {

        if (t.a == t1.a && t.a == t2.a && t.b == t1.b && t.b == t2.b)
            return true;
        else return false;
    }

    public static void main(String[] args) {

        Main m = new Main();

        int a = 12;
        int b = 43;

        System.out.println("beforee calling function ... ");
        System.out.println(a);
        System.out.println(b);
        m.f(a, b);
        System.out.println("after calling ... ");
        System.out.println(a);
        System.out.println(b);

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`");

        Test t = new Test(15, 20);
        System.out.println("before calling ");
        System.out.println("a = " + t.a + " ,  b = " + t.b);


        Test t1 = m.f(t);
        Test t2 = new  Test(12,23);

        if(m.Equal(t,t1,t2))
            System.out.println("these are equal");
        else
            System.out.println("these are not equal");
        System.out.println("after calling ");
        System.out.println("a = " + t.a + " ,  b = " + t.b);

        System.out.println("a = " + t1.a + " , b = " + t1.b);
        System.out.println(t.equalTo(t1));
    }
}
