public class Test{
    int a;
    int b;

    public Test()
    {
        this(0, 0);
        System.out.println("default");
    }
    public Test(int i, int j)
    {
        this.a = i;
        this.b = j;
    }

    public boolean equalTo(Test t){

        if(t.a == this.a && t.b == this.b)
            return true;
        else return false;
    }
}