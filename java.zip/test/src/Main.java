import java.util.Scanner;
public class Main {

    static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {

        int N = input.nextInt(); //50
        double s = 10, k = 10;
        int d = 1;
        int x = 21;
        while (s <= N) {

            k = k + k * 0.1;
            s += k;
            d++;
            System.out.println(s);
        }
        System.out.println(d);
    }
}