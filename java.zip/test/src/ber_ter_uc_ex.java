import java.util.Scanner;

public class ber_ter_uc_ex
{
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {

        String str  = input.next();

        System.out.println(str);


    }
}