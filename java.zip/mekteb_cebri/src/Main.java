import java.util.Scanner;
public class Main
{
    static Scanner in = new Scanner(System.in);
    public static void main(String ... args)
    {
        int a, b, c;
        a = in.nextInt(); b = in.nextInt(); c = in.nextInt();
        if(a == 0)
        {
            if(b == 0)
            {
                if(c == 0) System.out.println();
                else System.out.println(c);
            }
            else if(b > 0 && c > 0 && b != 1)
                System.out.println(b + "y+" + c);
            else if(c > 0 && b == 1)
                System.out.println("y+" + c);
            else if(b > 0 && c < 0 && b != 1)
                System.out.println(b + "y-" + -c);
            else if(c < 0 && b == 1)
                System.out.println("y-" + -c);
            else if(b > 0 && c == 0 && b != 1)
                System.out.println(b + "y");
            else if(b == 1 && c == 0)
                System.out.println("y");
            else if(b < 0 && c > 0 && b != -1)
                System.out.println("-" + -b + "y+" + c);
            else if(c > 0 && b == -1)
                System.out.println("-y+" + c);
            else if(b < 0 && c < 0 && b != -1)
                System.out.println("-" + -b + "y-" + -c);
            else if(c < 0 && b == -1)
                System.out.println("-y-" + -c);
            else if(b < 0 && c == 0 && b != -1)
                System.out.println("-" + -b + "y");
            else if(c == 0 && b == -1)
                System.out.println("-y");
        }
        else if(a > 0)
        {
            if(b == 0)
            {
                if(c == 0 && a != 1) System.out.println(a + "x");
                if(c == 0 && a == 1) System.out.println("x");
                else if(c > 0 && a != 1)
                    System.out.println(a + "x+" + c);
                else if(c > 0 && a == 1)
                    System.out.println("x+" + c);
                else if(c < 0 && a != 1)
                    System.out.println(a + "x-" + -c);
                else if(c < 0 && a == 1)
                    System.out.println("x-" + -c);
            }
            else if(b > 0 && c > 0 && a != 1 && b != 1)
                System.out.println(a + "x+" + b + "y+" + c);
            else if(b > 0 && c > 0 && a == 1 && b == 1)
                System.out.println("x+y+" + c);
            else if(b > 0 && c > 0 && a != 1 && b == 1)
                System.out.println(a + "x+y+" + c);
            else if(b > 0 && c > 0 && a == 1 && b != 1)
                System.out.println("x+" + b + "y+" + c);
            else if(b > 0 && c < 0 && a != 1 && b != 1)
                System.out.println(a + "x+" + b + "y-" + -c);
            else if(b > 0 && c < 0 && a == 1 && b == 1)
                System.out.println("x+y-" + -c);
            else if(b > 0 && c < 0 && a != 1 && b == 1)
                System.out.println(a + "x+y-" + -c);
            else if(b > 0 && c < 0 && a == 1 && b != 1)
                System.out.println("x+" + b + "y-" + -c);
            else if(b > 0 && c == 0 && a != 1 && b != 1)
                System.out.println(a + "x+" + b + "y");
            else if(b > 0 && c == 0 && a == 1 && b == 1)
                System.out.println("x+y");
            else if(b > 0 && c == 0 && a != 1 && b == 1)
                System.out.println(a + "x+y");
            else if(b > 0 && c == 0 && a == 1 && b != 1)
                System.out.println("x+" + b + "y");
            else if(b < 0 && c > 0 && a != 1 && b != -1)
                System.out.println(a + "x-" + -b + "y+" + c);
            else if(b < 0 && c > 0 && a == 1 && b == -1)
                System.out.println("x-y+" + c);
            else if(b < 0 && c > 0 && a != 1 && b == -1)
                System.out.println(a + "x-y+" + c);
            else if(b < 0 && c > 0 && a == 1 && b != -1)
                System.out.println("x-" + -b + "y+" + c);
            else if(b < 0 && c < 0 && a != 1 && b != -1)
                System.out.println(a  + "x-" + -b + "y-" + -c);
            else if(b < 0 && c < 0 && a == 1 && b == -1)
                System.out.println("x-y-" + -c);
            else if(b < 0 && c < 0 && a != 1 && b == -1)
                System.out.println(a  + "x-y-" + -c);
            else if(b < 0 && c < 0 && a == 1 && b != -1)
                System.out.println("x-" + -b + "y-" + -c);
            else if(b < 0 && c == 0 && a != 1 && b != -1)
                System.out.println(a + "x-" + -b + "y");
            else if(b < 0 && c == 0 && a == 1 && b == -1)
                System.out.println("x-y");
            else if(b < 0 && c == 0 && a != 1 && b == -1)
                System.out.println(a + "x-y");
            else if(b < 0 && c == 0 && a == 1 && b != -1)
                System.out.println("x-" + -b + "y");
        }
        else if(a < 0)
        {
            if(b == 0)
            {
                if(c == 0 && a != -1) System.out.println(a + "x");
                if(c == 0 && a == -1) System.out.println("-x");
                else if(c > 0 && a != -1)
                    System.out.println(a + "x+" + c);
                else if(c > 0 && a == -1)
                    System.out.println("-x+" + c);
                else if(c < 0 && a != -1)
                    System.out.println(a + "x-" + -c);
                else if(c < 0 && a == -1)
                    System.out.println("-x-" + -c);
            }
            else if(b > 0 && c > 0 && a != -1 && b != 1)
                System.out.println(a + "x+" + b + "y+" + c);
            else if(b > 0 && c > 0 && a == -1 && b == 1)
                System.out.println("-x+y+" + c);
            else if(b > 0 && c > 0 && a != -1 && b == 1)
                System.out.println(a + "x+y+" + c);
            else if(b > 0 && c > 0 && a == -1 && b != 1)
                System.out.println("-x+" + b + "y+" + c);
            else if(b > 0 && c < 0 && a != -1 && b != 1)
                System.out.println(a + "x+" + b + "y-" + -c);
            else if(b > 0 && c < 0 && a == -1 && b == 1)
                System.out.println("-x+y-" + -c);
            else if(b > 0 && c < 0 && a != -1 && b == 1)
                System.out.println(a + "x+y-" + -c);
            else if(b > 0 && c < 0 && a == -1 && b != 1)
                System.out.println("-x+" + b + "y-" + -c);
            else if(b > 0 && c == 0 && a != -1 && b != 1)
                System.out.println(a + "x+" + b + "y");
            else if(b > 0 && c == 0 && a == -1 && b == 1)
                System.out.println("-x+y");
            else if(b > 0 && c == 0 && a != -1 && b == 1)
                System.out.println(a + "x+y");
            else if(b > 0 && c == 0 && a == -1 && b != 1)
                System.out.println("-x+" + b + "y");
            else if(b < 0 && c > 0 && a != -1 && b != -1)
                System.out.println(a + "x-" + -b + "y+" + c);
            else if(b < 0 && c > 0 && a == -1 && b == -1)
                System.out.println("-x-y+" + c);
            else if(b < 0 && c > 0 && a != -1 && b == -1)
                System.out.println(a + "x-y+" + c);
            else if(b < 0 && c > 0 && a == -1 && b != -1)
                System.out.println("-x-" + -b + "y+" + c);
            else if(b < 0 && c < 0 && a != -1 && b != -1)
                System.out.println(a + "x-" + -b + "y-" + -c);
            else if(b < 0 && c < 0 && a == -1 && b == -1)
                System.out.println("-x-y-" + -c);
            else if(b < 0 && c < 0 && a != -1 && b == -1)
                System.out.println(a + "x-y-" + -c);
            else if(b < 0 && c < 0 && a == -1 && b != -1)
                System.out.println("-x-" + -b + "y-" + -c);
            else if(b < 0 && c == 0 && a != -1 && b != -1)
                System.out.println(a + "x-" + -b + "y");
            else if(b < 0 && c == 0 && a == -1 && b == -1)
                System.out.println("-x-y");
            else if(b < 0 && c == 0 && a != -1 && b == -1)
                System.out.println(a + "x-y");
            else if(b < 0 && c == 0 && a == -1 && b != -1)
                System.out.println("-x-" + -b + "y");
        }
    }
}