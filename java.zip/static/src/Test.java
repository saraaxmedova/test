public class Test {

    public static int a;
    static int b;
    private static int c;

    Test(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public static int getC() {
        return c;
    }

    static void incremnt() {
        a++;
        b++;
        c++;
    }


}
