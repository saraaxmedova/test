public class Main1 {

    static int i;
int j;
    static {
        i = 10;
        System.out.println("static block1");
    }
    Main1()
    {
        System.out.println("constructor");
    }
    {
        i = 19;
        j = 100;
        System.out.println("initiliaze block 1");
    }
    public static void main(String[] args) {
        Main1 m1 = new Main1();
        System.out.println(m1.j);
        System.out.println(i);
    }

    static {
        i = 50;
        System.out.println("static block 2");
    }
    {
        i = 29;
        j = 9;
        System.out.println("initiliaze block 2");
    }
}
