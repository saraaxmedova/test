public class Main {

    public static void main(String[] args) {

        Test t = new Test(1, 2, 3);
        Test r = new Test(10, 20, 30);

        System.out.println("t - nin deyerleri a = " + t.a + " b = " + t.b + " c = " + t.getC());
        System.out.println("r - nin deyerleri a = " + r.a + " b = " + r.b+ " c = " + t.getC());
        t.incremnt();
        r.incremnt();
        r.incremnt();
        System.out.println("t - nin deyerleri a = " + t.a + " b = " + t.b+ " c= " + t.getC());
        System.out.println("r - nin deyerleri a = " + r.a + " b = " + r.b+ " c = " + t.getC());
    }
}