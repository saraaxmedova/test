public class Main {

    public static void main(String[] args) {
//        A a1 = new A(4,3,7);
//        System.out.println(a1.No1());
//
//        A a2=new A(10);
//        System.out.println(a2.No1());
//
//        A a3=new A ( 10,4);
//        System.out.println(a3.No1());
//        A a4=new A ( 6,2,8);
//        System.out.println(a4.No1());

        B b1 = new B();
        System.out.println(b1.show1());
        B b2 = new B(7);
        System.out.println(b2.show1());
        B b3 = new B(2, 4);
        System.out.println(b3.show1());
        B b4 = new B(5, 3, 6);
        System.out.println(b4.show1());
        System.out.println("--------------------------------------------------");
//        C c1 = new C();
//        c1.show1();
//        C c2 = new C(7 );
//        c2.show1();
//        C c3 = new C(2,4);
//        c3.show1();
//        C c4 = new C(5,3,6);
//        c4.show2();
        A r = new A();
        r.ride();
        System.out.println("-------------------------");
        B r1 = new B();
        r1.ride();
        System.out.println("--------------------------");
        C r2 = new C();
        r2.ride();

    }
}
