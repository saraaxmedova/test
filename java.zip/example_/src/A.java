public class A {
    int a;
    int b;
    private int c;

    public A() {
        System.out.println("no parameter!! A");
    }

    public A(int m) {
        this(m, 2);
        this.a = m;
        System.out.println("one parameter");
    }

    public A(int m, int n) {
        this(m,n ,3);

        System.out.println("two parameters");
    }

    public A(int m, int n, int k) {
        this.a = m;
        this.b = n;
        this.c = k;
        System.out.println("three parameters A");
    }

    public int show() {
        return a * b - c;
    }
    public void ride(){
        System.out.println("AAAAAAA");
    }
}

class B extends A {
    @Override
    public void ride(){
        System.out.println("BBBBBBB");
    }

    public B() {
        super(12,4,9);
//        super();
        System.out.println("no parameter!! B");
    }

    public B(int i) {
        super(i, 7, 4);
        System.out.println("one parameter");
    }

    public B(int i, int j) {
        super(i, j, 6);
        System.out.println("two parameters");
    }
    public B(int i, int j, int k) {
//        super();
        super(i, j, k);
        this.a=i;
        this.b=j;
        System.out.println("three parameters B");
    }

    public int show1() {
        return super.show();
    }

}
class C extends B {
    @Override
    public void ride(){
        System.out.println("CCCCCCCC");
    }

    public C() {
        super(12,4,9);
//        super();
        System.out.println("no parameter!!");
    }

    public C(int f) {
        super(f, 7, 4);
        System.out.println("one parameter");
    }

    public C(int f, int g) {
        super(f, g, 6);
        System.out.println("two parameters");
    }
    public C(int f, int g, int h) {
        System.out.println("three parameters");
    }

    public void show2() {
        System.out.println(super.show1());
    }
}