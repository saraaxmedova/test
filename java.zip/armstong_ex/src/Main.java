public class Main {
    public static void main(String[] arg) {
        int n = 100, arm;
        while (n < 1000) {
            arm = armstrong(n);
            if (arm == n)
                System.out.println(n);
            n++;
        }
    }

    static int armstrong(int num) {
        int x, a = 0;
        while (num != 0) {
            x = num % 10;
            a = a + (x * x * x);
            num /= 10;
        }
        return a;
    }
}
