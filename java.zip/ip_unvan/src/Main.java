import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String str = scanner.next();
        int noqte = 0, eded = 0;
        boolean dogru = true;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == '.' && str.charAt(i + 1) != '.') {
                eded = 0;
                noqte++;
            }
            else if(str.charAt(i) == '.' && str.charAt(i + 1) == '.'){
                dogru =false;
                break;
            }
            else {
                eded = eded * 10 + str.charAt(i) - 48;
                if (eded < 0 || eded > 255) {
                    dogru = false;
                    break;
                }
            }
        }
        if (noqte == 3 && dogru)
            System.out.println("dogru ip unvan");
        else System.out.println("yanlis unvan");
    }
}
// 12.23.45.45