public class Main {

    public static void main(String[] args) {

        int arr[] = {2100, 50, 7, 23, 2};

        arr = Ac(arr);

        show(arr);

    }

    static void show(int arr[]) {
        for (int x : arr)
            System.out.print(x + " ");
        System.out.println();
    }

    public static int[] Ac(int arr[]) {
        int m;
        for (int i = 0; i < arr.length; i++) {

            for (int j = i + 1; j < arr.length; j++)
                if (arr[i] > arr[j]) {
                    m = arr[i];
                    arr[i] = arr[j];
                    arr[j] = m;
                }
            show(arr);
        }
        return arr;

    }
}

//    public static int[] Acsend(int a[]) {
//        int m;
//        for (int i = 0; i < a.length; i++) {
//
//            for (int j = 0; j < a.length - 1; j++)
//                if (a[j] > a[j + 1]) {
//                    m = a[j];
//                    a[j] = a[j + 1];
//                    a[j + 1] = m;
//                }
//        show(a);
//        }
//        return a;
//
//    }
}

//public class Main {
//
//    public static void main(String[] args) {
//
//        int arr[] = {2100, 50, 7, 23, 2};
//
//        arr = Acsend(arr);
//        for (int x : arr)
//            System.out.println(x);
//
//    }
//    static void show(int arr[])
//    {
//        for (int x : arr)
//            System.out.print(x + " ");
//
//        System.out.println();
//    }
//    public static int[] Acsend(int a[]) {
//        int m, temp;
//        for (int i = 0; i < a.length - 1; i++) {
//
//            m = i;
//            for (int j = i + 1; j < a.length; j++)
//                if (a[j] < a[m]) m = j;
//
//            temp = a[i];
//            a[i] = a[m];
//            a[m] = temp;
//            show(a);
//        }
//        return a;
//
//    }
//}

