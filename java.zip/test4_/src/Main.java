import java.util.Scanner;public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        double p = 3 * n;
        double d = n * n * Math.sqrt(3) / 4;
        System.out.printf("%.4f", p);
        System.out.println(" ");
        System.out.printf("%.4f", d);

    }
}
