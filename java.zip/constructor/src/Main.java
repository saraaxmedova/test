import pack.Constructor;
import pack.Test;

public class Main {
    public static void main(String[] args) {

//        Constructor c = new Constructor("Sara", 21, 2000);
//        Constructor c1 = new Constructor("Zaur", 25, 1500);
//        Constructor cc = new Constructor();
//        Constructor c2 = new Constructor("Name", 15);
//        c1.show();
//
//        System.out.println(c.name);
//        System.out.println(c.age);
//        System.out.println(c.module(-12));
//        System.out.println(c.module(12));
//        System.out.println(c.module(-12.2));
//        System.out.println(c.module(12.2, 16));
//        c.module();
        Test t1 = new Test();
        Test t2 = new Test(12);
        Test t3= new Test(13, 18);
    }
}
