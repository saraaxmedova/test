package pack;

public class Test {
    int a, b;

    public Test()
    {
        this(10);
        System.out.println("default constructor ..");
    }
    public Test (int i)
    {
        this(i, i);
        System.out.println("one parameter");
    }
    public Test(int i, int j)
    {
        System.out.println("two parameter");
        this.a = i;
        this.b = j;
    }
}