package pack;

public class Constructor {
public static  int x;
    public String name;
    public int age;
    public double salary;

    public Constructor() {
        System.out.println("calling default constructor ...");
    }

    public Constructor(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
        System.out.println("calling parametrized constructor ...");
    }

    public void show()
    {
        System.out.println(this.name);
        System.out.println(this.age);
        System.out.println(this.salary);
    }

    public Constructor(String name, int age) {
        this.name = name;
        this.age = age;
        this.salary = 1000;
    }

    public int module(int x) {
        System.out.println("int parameter");
        if (x < 0)
            return -x;
        else return x;
    }

    public double module(double d) {
        System.out.println("double parameter");
        if (d < 0)
            return -d;
        else return d;
    }

    public double module(double d, int w) {
        System.out.println("double int parameter");
        if (d < 0)
            return -d;
        else return d;
    }

    public short module(int s, int x) {
        System.out.println("two parameter ");
        return (short) s;
    }

    public void module(String s) {
        System.out.println("without parameter");
    }

    public void module() {
        System.out.println("jfremlr,f");
    }
}