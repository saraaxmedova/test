import java.util.Random;

public class Main {

    static void showArr(int[] arr) {
        System.out.println("show array elements ... ");
        System.out.println("length of array " + arr.length);
        for (int x : arr)
            System.out.print(x + " ");

        System.out.println();
    }

    static void showParameters(String str, int... varargs) {
        System.out.println("length of varargs parameters .. " + varargs.length);
        for (int i = 0; i < varargs.length; i++)
            System.out.print(varargs[i] + " ");
        System.out.println();
    }
    static void showParameters(int ... varargs)
    {
        for (int i = 0; i < varargs.length; i++)
            System.out.print(varargs[i] + " ");
        System.out.println();
    }

    static void showParameters(short ... varargs)
    {
        for (int i = 0; i < varargs.length; i++)
            System.out.print(varargs[i] + " ");
        System.out.println();
    }
    static void showParameters(boolean ... varargs)
    {
        for (int i = 0; i < varargs.length; i++)
            System.out.print(varargs[i] + " ");
        System.out.println();
    }

    static void ortalama(String s, int... varargs) {

        int total = 0;
        for (int i = 0; i < varargs.length; i++)
            total += varargs[i];

        if (varargs.length != 0)
            total = total / varargs.length;
        if (total == 0)
            System.out.println(s + " kesilmisiz .. ");
        else {
            System.out.print(s + " - in ortalama qiymetleri ");
            System.out.println(total);
        }
    }
    public static void main(String[] args) {

       Random rand = new Random();
       int a = rand.nextInt(100);
        System.out.println(a);
        int[] arr = new int[7];
        int[] arr1 = {1, 2, 3, 4, 5};
        for (int i = 0; i < arr.length; i++)
            arr[i] = i + 1;
//        showArr(arr);
//        showArr(arr1);
//        showParameters("arr", arr);
//        showParameters("some parameters", 1, 4, 6);
//        showParameters("saaa");
//        ortalama("Sara", 7, 9, 10);
//        ortalama("Meleyke", 10, 9);
//        ortalama("Elish");
       // showParameters(); error
        showParameters(12>45, true);
        showParameters(12!= 4);
    }
}