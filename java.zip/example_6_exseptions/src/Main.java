public class Main {
    static void check(int c)
    {
        if (c<16)
            throw new ArithmeticException("jrjlklkdslds");
        else
            System.out.println("u are right");
    }

    public static void main(String[] args) {
check(14);
//   try {
//       int[] a={2,4,5};
//       System.out.println(a[6]);
//   }
//   catch (Exception e)
//   {
//       System.out.println("wrong expression!!");
//   }
//   finally {
//       System.out.println("finished!!");
//   }

    }
}
