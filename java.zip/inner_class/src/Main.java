public class Main {

    private int x = 20;

    public int getX() {
        return x;
    }

    public static void main(String[] args) {

        Main m = new Main();

       m.display();
    }

    void display()
    {
        Inner inner = new Inner();
        System.out.println(inner.get());
    }

    public class Inner {

        int get() {
            return x;
        }
//abstact class
    }
}
