public class Main {

    public static void main(String[] args)
    {
        String str="i am alone";
        System.out.println(str.length());
        System.out.println(str.toLowerCase());
        System.out.println(str.toUpperCase());
        System.out.println(str.indexOf("m"));
        System.out.println(Math.max(3,4));
        System.out.println(Math.min(5.1,-1.2));
        System.out.println(Math.sqrt(4));
        System.out.println(Math.ceil(5.1));
        System.out.println(Math.floor(3.9));
        System.out.println(Math.round(5.5));
        System.out.println(Math.random());
        System.out.println(Math.pow(2,4));
        System.out.println(Math.sin(2.1));
        System.out.println(Math.abs(-3.6));
    }
}
