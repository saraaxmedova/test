public class Main {

    public static void main(String[] args) {

        if (32 > 0) {
            System.out.println("true1");
            if ((float) 2.2 == (float) (12.2 % 10)) {
                System.out.println("true");
                if (!true ^ false & (false | !(true ^ false))) {
                    System.out.println("true");
                } else System.out.println("false");
                System.out.println("other");
            } else System.out.println("false1");
        } else if (!false)
            System.out.println("true");
        else System.out.println("false");
        int a = 3;
        int b, c;
        b = c = a;

        c = a != b ? a : c == b ? -c : 0;
        System.out.println(c);

        switch (a) {
            case 1:
                System.out.println("yay");
                break;
            case 2:
                System.out.println("yaz");
                break;
            case 3:
                System.out.println("payiz");
                break;
            case 4:
                System.out.println("qış");
                break;
            default:
                System.out.println("error");
        }
        boolean t = true;
        first:
        {
            second:
            {
                third:
                {
                    System.out.println("third");
                    if (t) break second;
                    System.out.println("third 2");
                }
                System.out.println("second");
            }
            System.out.println("first");
        }

//        F:
//        for (int i = 0; i < 2; i++) {
//            G:
            for (int j = 0; j < 5; j++) {
                if (j == 3 )
                    return;
                System.out.println(j);
            }
//        }

//int s = (21, 3, 15);
        // for(int i = 0, j < 3; i < 1, j < 10; i++, j++);
        for(int i = 0, j = 2; i < 2 ; i++, System.out.println("sasas"));

    }
}
//0
//0 1
//0 2 4
//0 3 6 9
//0 4 8 12 16
//0 5 10 15 20 25