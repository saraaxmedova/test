public class Main {

    public static long Fac(int f) {
        long n = 1;
        for (int i = 1; i <= f; i++) {
            n = n * i;
        }
        System.out.println(n);
        return n;
    }











    public static long Fact(int f) // f = 5
    {
        if (f == 1)
            return 1;
        else
            return f * Fact(f - 1); // 20 * Fact(3)
    }

    public static int Fib(int fib) {
        if (fib == 0)
            return 0;
        else if (fib == 1)
            return 1;
        else
            return Fib(fib - 1) + Fib(fib - 2);
    }

    public static void main(String ... args) {

        Fac(5);

        for (int i = 1; i <= 8; i++)
            System.out.println(i + " : " + Fib(i));

        int f[] = new int[8];
        f[0] = 0;
        f[1] = 1;

        for (int i = 2; i < 8; i++) {
            f[i] = f[i - 1] + f[i - 2];
        }

        for (int i = 0; i < 8; i++) {
            System.out.print(f[i] + " ");
        }

//        int m = 8,first=0,second=1,next;
//        for(int i=1;i<m;i++){
//            if(m<=1)
//                System.out.println(1);
//            else {
//                next = first + second;
//                first = second;
//                second = next;
//            }
//
//        }
    }
}