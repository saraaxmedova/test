public class Main {

    public static void main(String[] args) {

        Test t = new Test3();

        System.out.println(t.x);
        t.show();

        Test2 t1= new Test3();
        System.out.println(t1.x);
        t1.showparameter(t1.x);

        A a = new Test5();
        a.getNumber(15);
        a.getString("string");

        singl s = singl.getInstance();
        System.out.println(s.a);
    }
}