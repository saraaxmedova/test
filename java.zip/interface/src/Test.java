public interface Test {

    int x = 34;
    void show();
}

interface Test2 {
    int x = 6;

    void showparameter(int x);
}
class Test1{

}
class Test3 extends Test1 implements Test , Test2{
    @Override
    public void show() {
        System.out.println("from Test3");
    }

    @Override
    public void showparameter(int x) {
        System.out.println("x = "+ x);
    }
}