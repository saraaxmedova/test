public interface I1 {

    void meth1();
}

interface I2 extends I1{
    void meth2();
}

interface I3 extends I2{
    void meth3();
}
class Demo implements I3{
    @Override
    public void meth1() {

    }

    @Override
    public void meth2() {

    }

    @Override
    public void meth3() {

    }
}

class singl {

    private singl() {
        System.out.println("private constructor");
    }

    int a = 0;

    public static singl getInstance() {
        return new singl();
    }

}