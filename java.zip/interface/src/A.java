public interface A {

    void getNumber(int x);

    default void getString(String str){
        System.out.println(str);
    }
}

class Test5 implements A{

    public void getNumber(int x)
    {
        System.out.println(x);
    }
//    public  void getString(String str)
//    {
//        System.out.println("str = " + str );
//    }
}