public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        float n;

        double p=3*n;
        double s=sqrt(3.0)*n*n/4;
    }
}
