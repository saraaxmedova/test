import java.util.Arrays;
public class SortExamplemali
{
    public static void main(String[] args)
    {
        int[] arr = {13, 7, 6, 45, 21, 9};

        Arrays.sort(arr);
// amma sort meselesini bele etmeyecen ozun yaz alqoritmi ok
        //yaxwi
        System.out.printf(Arrays.toString(arr));
    }
    public static str Acsend(str)
}