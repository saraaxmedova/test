public class Main {
    public static void main(String[] args) {
       Main f91= new Main();
        System.out.println(f91.F91(500));

    }
   public static int F91(int n)
    {
        if(n<=100)
            return F91(F91(n+11));
        else if (n>=101)
            return n-10;
            return 0;
    }
}